package Models.Elements.NatrualDisasters;

import Models.Elements.Hex.Hex;
import Models.Logic.NaturalDisasterLogic.NaturalDisasterLogic;
import Models.Model;

import java.util.ArrayList;

public class NaturalDisaster extends Model {
    protected ArrayList<Hex> effectRadius;
    protected final Hex hex;
    protected ArrayList<Class<? extends Hex>> HEX_TYPE;
    protected Class<? extends NaturalDisasterLogic> logic;

    public NaturalDisaster(Hex hex) {
        this.hex = hex;
        effectRadius = new ArrayList<>();
        HEX_TYPE = new ArrayList<>();
        generateID();
    }

    public ArrayList<Hex> getEffectRadius() {
        return effectRadius;
    }

    public Hex getHex() {
        return hex;
    }

    public ArrayList<Class<? extends Hex>> getHEX_TYPE() {
        return HEX_TYPE;
    }

    public void setEffectRadius(ArrayList<Hex> effectRadius) {
        this.effectRadius = effectRadius;
    }

    public void setHEX_TYPE(ArrayList<Class<? extends Hex>> HEX_TYPE) {
        this.HEX_TYPE = HEX_TYPE;
    }

    public Class<? extends NaturalDisasterLogic> getLogic() {
        return logic;
    }

    public void setLogic(Class<? extends NaturalDisasterLogic> logic) {
        this.logic = logic;
    }
}
