package Models.Logic.TribeLogic.Behaviors;

public class Behavior {
}
